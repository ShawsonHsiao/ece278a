1. Image Alignment by Peicheng Wu
2. Image Stitching by Shawson Hsiao
3. Paper presentation(An effective feature detection approach for image stitching of near-           uniform scenes) by Shang-Hsun Yang


******************************************************************************************
The pic file contains all the images needed in the presentation
The code can directly run on jupyter notebook